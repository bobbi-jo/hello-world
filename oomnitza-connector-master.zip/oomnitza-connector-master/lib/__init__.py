TrueValues = ['True', 'true', '1', 'Yes', 'yes', True, 1, 'Y', 'y']
FalseValues = ['False', 'false', '0', 'No', 'no', False, 0, 'N', 'n']
