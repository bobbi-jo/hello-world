class ConfigError(RuntimeError):
    pass


class AuthenticationError(RuntimeError):
    pass
